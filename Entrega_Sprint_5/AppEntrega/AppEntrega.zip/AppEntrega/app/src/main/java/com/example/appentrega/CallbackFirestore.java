package com.example.appentrega;

public interface CallbackFirestore {
    public void onSuccess(Object object);
    public void onFailure(Object object);

}

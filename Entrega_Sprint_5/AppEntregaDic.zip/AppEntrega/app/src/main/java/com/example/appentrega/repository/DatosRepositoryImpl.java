package com.example.appentrega.repository;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.appentrega.CallbackFirestore;
import com.example.appentrega.Usuario;
import com.example.appentrega.model.Persona;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


public class    DatosRepositoryImpl implements DatosRepository{
    final static String COLLECTION = "datosIMC";
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    @Override
    public void crear(Persona persona, CallbackFirestore callback) {
        db.collection(COLLECTION)
                .document(persona.getEmail())
                .set(persona.getMap())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        callback.onSuccess(persona);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        callback.onFailure(e);
                    }
                });
    }

    @Override
    public void leePersonas(ArrayList<Persona> personas, CallbackFirestore callback) {
        String mail= Usuario.getInstance().getMail();//mail usuario actual
        if(mail.contains(".es")) {
            leePersona(mail,personas,callback);
        }else{//lee todos
            db.collection(COLLECTION)
            .get()
            .addOnCompleteListener((Task<QuerySnapshot> task) -> {
                if (task.isSuccessful()) {
                    for (DocumentSnapshot doc : task.getResult().getDocuments()) {
                        Persona persona = new Persona(doc.getData());
                        personas.add(persona);
                        Log.d("@OJO en lista:", personas.size()+"");
                    }
                    callback.onSuccess(personas);
                } else {
                    callback.onFailure(null);
                }
            });
        }
    }

    public void leePersona(String mail,ArrayList<Persona> personas, CallbackFirestore callback) {
        db.collection(COLLECTION)
                .document(mail)
                .get()
                .addOnCompleteListener((Task<DocumentSnapshot> task) -> {
                    if (task.isSuccessful()) {
                        Persona persona = new Persona(task.getResult().getData());
                        personas.add(persona);
                        Log.d("@OJO en lista1:", personas.size()+"");
                        callback.onSuccess(personas);
                    }else {
                        callback.onFailure(null);
                    }
                });
    }


}

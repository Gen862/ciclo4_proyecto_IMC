package com.example.appentrega.repository;

import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.appentrega.CallbackFirestore;
import com.example.appentrega.model.Datos;
import com.example.appentrega.model.Persona;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firestore.v1.DocumentTransform;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public class    DatosRepositoryImpl implements DatosRepository{
    final static String COLLECTION = "datosIMC";//"datosUsuario";
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    public void crear(Persona persona, CallbackFirestore callback) {
        db.collection(COLLECTION)
                .document(persona.getEmail())
                .set(persona.getMap())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        callback.onSuccess(persona);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        callback.onFailure(e);
                    }
                });
    }
    @Override
    public void consultarTodos(ArrayList<Persona>personas,CallbackFirestore callback) {
        db.collection(COLLECTION)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()){
                            for (DocumentSnapshot doc : task.getResult().getDocuments()) {
                                //Log.d("OJO lee", doc.getId() + " = " + doc.getData());
                                Persona persona=new Persona();
                                persona.setEmail(doc.get("email")==null?"":doc.get("email").toString());
                                persona.setTipo(doc.get("tipo")==null?"":doc.get("tipo").toString());
                                persona.setNota(doc.get("nota")==null?"":doc.get("nota").toString());
                                persona.setGenero(doc.get("genero")==null?"":doc.get("genero").toString());
                                persona.setFecha(doc.get("fecha")==null?new Date():(Date) doc.getTimestamp("fecha").toDate());
                                persona.setEstatura(doc.get("estatura")==null?0F: ((Double) doc.get("estatura")).floatValue());
                                persona.setEdad(doc.get("edad")==null?0F:((Double)doc.get("edad")).floatValue());
                                persona.setPeso(doc.get("peso")==null?0F:((Double)doc.get("peso")).floatValue());
                                persona.setImc(doc.get("imc")==null?0F:((Double)doc.get("imc")).floatValue());
                                persona.setBasal(doc.get("basal")==null?0F:((Double)doc.get("basal")).floatValue());
                                Log.d("@OJO en lista:",persona.toString());
                                personas.add(persona);
                            }
                            callback.onSuccess(personas);
                        } else{
                            callback.onFailure(null);
                        }
                    }
                });
    }
    public void consultarPersona(String mail, CallbackFirestore callback) {
        db.collection(COLLECTION)
                .whereEqualTo("mail",mail)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()){
                            callback.onSuccess(task.getResult().getDocuments());
                        }else{
                            callback.onFailure(null);
                        }
                    }
                });
    }


}

package com.example.appentrega.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Datos implements Serializable {
    private Float estatura;
    private Float edad;
    private Float peso;
    private String imc; // indice de masa corporal
    private String imb; // indice de metabolico basal
    private String estadopeso; // tipo de peso

    public Datos() {
    }

    public Datos(Float estatura, Float edad, Float peso, String imc, String imb, String estadopeso) {
        this.estatura = estatura;
        this.edad = edad;
        this.peso = peso;
        this.imc = imc;
        this.imb = imb;
        this.estadopeso = estadopeso;
    }

    public Float getEstatura() {
        return estatura;
    }

    public void setEstatura(Float estatura) {
        this.estatura = estatura;
    }

    public Float getEdad() {
        return edad;
    }

    public void setEdad(Float edad) {
        this.edad = edad;
    }

    public Float getPeso() {
        return peso;
    }

    public void setPeso(Float peso) {
        this.peso = peso;
    }

    public String getImc() {
        return imc;
    }

    public void setImc(String imc) {
        this.imc = imc;
    }

    public String getImb() {
        return imb;
    }

    public void setImb(String imb) {
        this.imb = imb;
    }

    public String getEstadopeso() {
        return estadopeso;
    }

    public void setEstadopeso(String estadopeso) {
        this.estadopeso = estadopeso;
    }

    public Map<String, Object> getMap(){
        Map<String,Object> mapa= new HashMap<>();
        mapa.put("estatura",this.getEstatura());
        mapa.put("edad",this.getEdad());
        mapa.put("peso",this.getPeso());
        mapa.put("imc",this.getImc());
        mapa.put("imb",this.getImb());
        mapa.put("tipo_peso",this.getEstadopeso());
        mapa.put("fecha_registro",new Date());
        return mapa;

    }
    public String getReference(){
        return this.getImc();
    }

}

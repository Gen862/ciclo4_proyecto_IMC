package com.example.appentrega;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.appentrega.model.Persona;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.security.acl.Group;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private Button registrar;
    private Button ingreso;
    private Button logOut;
    private RadioButton tipo;
    private Persona persona;
    private String emailtexto,passwordtexto,tipoCom;

    private final String TAG = "OJO log Autentication";
    EditText password, mail;

    public MainActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("App IMC v1.0");
        mAuth = FirebaseAuth.getInstance();
        persona = (Persona) getIntent().getSerializableExtra("persona");
        if (persona == null) persona = new Persona();
        password = (EditText) findViewById(R.id.contrasenaType);
        mail = (EditText) findViewById(R.id.emailType);
        ingreso = (Button) findViewById(R.id.aceptar);
        registrar = (Button) findViewById(R.id.registrar_usuario);
        logOut = (Button) findViewById(R.id.logOut);
        tipo=(RadioButton)findViewById(R.id.comun_univ);
        ingreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailtexto = mail.getText().toString();
                passwordtexto = password.getText().toString();
                tipoCom=tipo.isChecked()?"Universitaria":"Bienestar";
                sigInWithFireBase(emailtexto, passwordtexto);
                FirebaseUser currentUser = mAuth.getCurrentUser();
                if(currentUser != null && emailtexto.equals(currentUser.getEmail())) {//usuario ok y registrado
                    Intent intent = new Intent(MainActivity.this, Activity_Datos.class);
                    persona=new Persona(emailtexto,tipoCom);
                    intent.putExtra("persona", persona);
                    startActivity(intent);
                    finish();
                }else{ //credenciales invalidas o usuario nuevo
                    Toast.makeText(MainActivity.this, "Verificar Credenciales...",Toast.LENGTH_LONG).show();
                }

            }
        });
        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailtexto = mail.getText().toString();
                passwordtexto = password.getText().toString();
                if (!emailtexto.isEmpty() && !passwordtexto.isEmpty()) {
                    if (passwordtexto.length() >= 8) {
                        registerUser(emailtexto, passwordtexto);
                    } else {
                        Toast.makeText(MainActivity.this, "El password tiene que tener 8 caracteres",
                                Toast.LENGTH_LONG).show();
                    }
                }

            }
        });




        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(MainActivity.this, "Sesión teminada", Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void sigInWithFireBase(String mail, String clave) {
        mAuth.signInWithEmailAndPassword(mail, clave)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                        } else {
                            Log.d(TAG, "signInWithEmail:failure", task.getException());
                            //Toast.makeText(MainActivity.this, "Authentication Failed",Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }

    private void registerUser(String mail, String clave) {
        mAuth.createUserWithEmailAndPassword(mail, clave)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "regristro de usuario existoso");

                        } else {
                            Toast.makeText(MainActivity.this, "No se puedo registrar el usuario",
                                    Toast.LENGTH_SHORT).show();
                            Log.d(TAG, task.getException().getMessage());

                        }
                    }
                });
    }

}

package com.example.appentrega;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.example.appentrega.model.Persona;
import com.example.appentrega.repository.DatosRepository;
import com.example.appentrega.repository.DatosRepositoryImpl;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Activity_Reporte extends AppCompatActivity {
    private ArrayList<Persona>personas=new ArrayList<>();
    RecyclerView recyclerView;
    DatosRepository repository;
    CallbackFirestore callbackLee;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reporte);
        this.setTitle("Reporte IMC");
        repository = new DatosRepositoryImpl();
        callbackLee=new CallbackFirestore() {
            @Override
            public void onSuccess(Object object) {
                //personas=(ArrayList<Persona>) object;
                Log.d("@OJO:personas=",personas.size()+"");
            }
            @Override
            public void onFailure(Object object) {
                personas=new ArrayList<>();
            }
        };
        repository.consultarTodos(personas,callbackLee);
        PersonaAdapter personaAdapter = new PersonaAdapter(personas);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(personaAdapter);

        ImageButton backDatos=(ImageButton)findViewById(R.id.rDatos) ;
        backDatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Activity_Reporte.this,Activity_Datos.class);
                intent.putExtra ("personas", personas);
                startActivity(intent);
                finish();
            }
        });


    }



}
package com.example.appentrega.repository;

import android.net.SocketKeepalive;

import androidx.appcompat.view.ActionMode;

import com.example.appentrega.CallbackFirestore;
import com.example.appentrega.model.Datos;
import com.example.appentrega.model.Persona;

import java.util.ArrayList;

public interface DatosRepository {
    public void crear (Persona persona, CallbackFirestore callback);
    public void consultarTodos (ArrayList<Persona> personas,CallbackFirestore callback);
    public void consultarPersona(String mail,CallbackFirestore callback);

}
